// ===================== SETTING VIDEO =====================
// Ganti URL / path file di sini (contoh file sendiri: '/banner.mp4').
const BANNER_VIDEO = 'https://files.catbox.moe/ci1cn0.mp4'; // video banner di Beranda
const BG_VIDEO = 'https://files.catbox.moe/ci1cn0.mp4';     // video background semua halaman

function videoFail(el, label) {
    const src = el.currentSrc || el.getAttribute('src') || '';
    const show = (m) => {
        console.warn('[video] ' + label + ': ' + m + ' (' + src + ')');
        if (label === 'Banner' && el.parentElement) el.parentElement.setAttribute('data-err', 'Banner gagal dimuat: ' + m);
    };
    fetch(src, { method: 'HEAD' }).then(r => {
        show(r.ok ? 'file ada tapi format/codec tidak didukung browser (pakai H.264)' : 'HTTP ' + r.status + (r.status === 404 ? ' - file tidak ditemukan, cek nama/path' : ''));
    }).catch(() => show('tidak bisa diakses'));
}
function startBgVideo() {
    const bg = document.getElementById('bgVideo');
    if (!bg || bg.getAttribute('src')) return;
    bg.addEventListener('error', () => videoFail(bg, 'Background'));
    bg.src = BG_VIDEO;
    const p = bg.play();
    if (p && p.catch) p.catch(() => {});
}
function initVideos() {
    const bv = document.getElementById('bannerVideo');
    if (bv) {
        bv.addEventListener('error', () => videoFail(bv, 'Banner'));
        if (!bv.getAttribute('src')) bv.src = BANNER_VIDEO;
        bv.addEventListener('canplay', startBgVideo, { once: true }); // background menyusul setelah banner siap
    }
    setTimeout(startBgVideo, 8000); // jaring pengaman kalau banner lama/gagal
}
initVideos();

function runLoader() {
    const loaderEl = document.getElementById('loader');
    if (!loaderEl || loaderEl.dataset.done) return;
    loaderEl.dataset.done = '1';
    const msgs = ['LOADING MODULES...', 'CONNECTING API...', 'UNLOCKING TOOLS...', 'READY!'];
    let pct = 0;
    const iv = setInterval(() => {
        pct = Math.min(100, pct + 2 + Math.random() * 4);
        document.getElementById('ldFill').style.width = pct + '%';
        document.getElementById('ldPct').textContent = Math.floor(pct) + '%';
        document.getElementById('ldStatus').textContent = msgs[Math.min(3, Math.floor(pct / 26))];
        if (pct >= 100) {
            clearInterval(iv);
            setTimeout(() => {
                const done = () => loaderEl.classList.add('hide');
                try { checkAuth().then(done, done); } catch (e) { done(); }
                setTimeout(done, 5000); // jaring pengaman: splash tidak boleh nyangkut
            }, 350);
        }
    }, 80);
}
// Dulu dengarin 'load', yang nunggu SEMUA resource kelar termasuk video
// background dari luar (catbox.moe). Kalau video itu lambat/gagal/throttled,
// event 'load' bisa telat banget atau gak kepanggil sama sekali -> splash
// nyangkut di 0%. Sekarang jalan begitu HTML selesai di-parse (DOMContentLoaded),
// gak perlu nunggu video/gambar. Ditambah fallback keras biar GAK AKAN
// nyangkut lagi walau ada bug lain di kemudian hari.
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', runLoader);
} else {
    runLoader();
}
setTimeout(runLoader, 4000); // jaring pengaman terakhir

function toast(msg) {
    let t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(t._hide);
    t._hide = setTimeout(() => t.classList.remove('show'), 2000);
}

// Akun DEV TIDAK disimpan di file ini. Dicek di server (api/login.js) pakai env Vercel DEV_USER & DEV_PASS.
let devVerified = false, devName = '';
const WA_NUM = '6285656564944';
const WA_TEXT = '*Halo Saya Ingin Upgrade Ke VIP saya mau unlock fitur all tools VIP Dengan Harga 15.000 Kirim Payment Mimin*';

function getUsers() {
    let u = {};
    try { u = JSON.parse(localStorage.getItem('vip_users') || '{}'); } catch {}
    return u;
}
function getRoles() { try { return JSON.parse(localStorage.getItem('vip_roles') || '{}'); } catch { return {}; } }
function getRole() {
    const u = localStorage.getItem('vip_session');
    if (devVerified && u && u === devName) return 'DEV';
    return getRoles()[u] === 'ADMIN' ? 'ADMIN' : (getRoles()[u] === 'VIP' ? 'VIP' : 'MEMBER');
}
function isVip() { return getRole() !== 'MEMBER'; }
function applyRole() {
    const role = getRole();
    document.querySelectorAll('.role-label').forEach(e => e.textContent = '✦ ' + role);
    document.getElementById('devMenu').style.display = role === 'DEV' ? 'flex' : 'none';
    document.getElementById('devMenu2').style.display = role === 'DEV' ? 'flex' : 'none';
    document.getElementById('devMenu3').style.display = role === 'DEV' ? 'flex' : 'none';
    document.getElementById('devMenu4').style.display = role === 'DEV' ? 'flex' : 'none';
    document.getElementById('devMenu5').style.display = role === 'DEV' ? 'flex' : 'none';
    document.getElementById('devMenu6').style.display = role === 'DEV' ? 'flex' : 'none';
    document.getElementById('adminMenu').style.display = ['DEV','ADMIN'].includes(role) ? 'flex' : 'none';
    if (document.getElementById('toolsPage').classList.contains('active')) renderCategory(currentCat);
    renderGrid('popularGrid', popularTools());
}
function doUpgrade() {
    const u = document.getElementById('upgUser').value.trim();
    const p = document.getElementById('upgPass').value;
    const st = document.getElementById('upgStatus');
    if (getRole() !== 'DEV') return toast('Khusus DEV!');
    if (!u || !p) { st.style.color = '#dc2626'; st.textContent = '⚠️ Isi username & password pembeli!'; return; }
    const users = getUsers();
    if (!users[u] || users[u] !== btoa(p)) { st.style.color = '#dc2626'; st.textContent = '❌ Username / password pembeli salah.'; return; }
    const roles = getRoles(); roles[u] = 'VIP';
    localStorage.setItem('vip_roles', JSON.stringify(roles));
    st.style.color = '#22c55e'; st.textContent = '✅ ' + u + ' sekarang VIP. Semua tools VIP terbuka.';
    document.getElementById('upgUser').value = ''; document.getElementById('upgPass').value = '';
}
function toggleTheme(force) {
    const el = document.documentElement;
    const on = typeof force === 'boolean' ? force : !el.classList.contains('theme-nexora');
    el.classList.toggle('theme-nexora', on);
    localStorage.setItem('nx_theme', on ? 'nexora' : 'pink');
    toast(on ? 'Tema: Biru Tua Ungu Hitam' : 'Tema: Default');
}
if (localStorage.getItem('nx_theme') === 'nexora') document.documentElement.classList.add('theme-nexora');

function openLock(name) {
    document.getElementById('lockTool').textContent = name;
    document.getElementById('lockWa').href = 'https://wa.me/' + WA_NUM + '?text=' + encodeURIComponent(WA_TEXT);
    document.getElementById('lockModal').classList.add('show');
}
function closeLock() { document.getElementById('lockModal').classList.remove('show'); }
function saveUsers(u) { localStorage.setItem('vip_users', JSON.stringify(u)); }

function switchAuth(view) {
    document.getElementById('loginView').style.display = view === 'login' ? 'block' : 'none';
    document.getElementById('registerView').style.display = view === 'register' ? 'block' : 'none';
}
async function doRegister() {
    let u = document.getElementById('regUser').value.trim();
    let p = document.getElementById('regPass').value;
    let p2 = document.getElementById('regPass2').value;
    if (!u || !p) return toast('Isi username & password!');
    if (p !== p2) return toast('Konfirmasi password tidak cocok!');
    try { const r=await fetch('/api/accounts',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'register',username:u,password:p})}); const d=await r.json().catch(()=>({})); if(!r.ok||!d.ok) return toast(d.message||'Gagal membuat akun.'); } catch { return toast('Database tidak dapat dihubungi. Coba lagi.'); }
    toast('Akun berhasil dibuat! Silakan login.');
    switchAuth('login');
    document.getElementById('loginUser').value = u;
}
function loginMsg(t, ok) {
    const el = document.getElementById('loginMsg');
    if (el) { el.textContent = t || ''; el.style.color = ok ? '#22c55e' : 'var(--primary-light)'; }
}
async function doLogin() {
    let u = document.getElementById('loginUser').value.trim();
    let p = document.getElementById('loginPass').value;
    if (!u || !p) { loginMsg('Isi username & password!'); return toast('Isi username & password!'); }
    try { const ar=await fetch('/api/accounts',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'login',username:u,password:p})}); const ad=await ar.json().catch(()=>({})); if(ar.ok&&ad.ok){ localStorage.removeItem('vip_dev_token');devVerified=false;devName='';localStorage.setItem('vip_session',ad.user);if(ad.token)localStorage.setItem('vip_dev_token',ad.token);const roles=getRoles();if(ad.role==='VIP'||ad.role==='ADMIN')roles[ad.user]=ad.role;else delete roles[ad.user];localStorage.setItem('vip_roles',JSON.stringify(roles));loginMsg('');return enterApp(ad.user); } } catch {}
    let users = getUsers();
    if (users[u] && users[u] === btoa(p)) {
        localStorage.removeItem('vip_dev_token'); devVerified = false; devName = '';
        localStorage.setItem('vip_session', u);
        loginMsg('');
        return enterApp(u);
    }
    // bukan akun lokal -> cek ke server (akun DEV, kredensialnya ada di env Vercel)
    const btn = document.querySelector('#loginView .btn-auth');
    if (btn) btn.disabled = true;
    loginMsg('Memproses...', true);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 12000);
    try {
        const r = await fetch('/api/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ username: u, password: p }), signal: ctrl.signal });
        const d = await r.json().catch(() => ({}));
        if (r.ok && d.ok) {
            localStorage.setItem('vip_dev_token', d.token);
            devVerified = true; devName = d.user;
            localStorage.setItem('vip_session', d.user);
            loginMsg('');
            return enterApp(d.user);
        }
        let msg = 'Username / password salah!';
        if (r.status === 500 && d.message) msg = d.message;
        else if (r.status === 404) msg = 'Server login tidak ditemukan (folder api/ belum ter-deploy).';
        else if (r.status !== 401) msg = 'Server error (HTTP ' + r.status + ').';
        loginMsg(msg); toast(msg);
    } catch (e) {
        const msg = e && e.name === 'AbortError' ? 'Server tidak merespons (timeout 12 detik).' : 'Gagal terhubung ke server, coba lagi.';
        loginMsg(msg); toast(msg);
    } finally { clearTimeout(timer); if (btn) btn.disabled = false; }
}
async function verifyDev() {
    devVerified = false; devName = '';
    const token = localStorage.getItem('vip_dev_token');
    if (!token) return;
    try {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), 4000);
        const r = await fetch('/api/verify', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token }), signal: ctrl.signal });
        clearTimeout(timer);
        const d = await r.json();
        if (d.ok) { devVerified = true; devName = d.user; }
        else localStorage.removeItem('vip_dev_token');
    } catch {}
}
function doLogout() {
    clearNav();
    localStorage.removeItem('vip_session');
    localStorage.removeItem('vip_dev_token'); devVerified = false; devName = '';
    toast('Logout berhasil');
    // tutup semua panel yang melayang supaya tidak nyangkut di atas halaman login
    closeSidebar();
    closeTool();
    closeLock();
    mStop();
    document.getElementById('musicPanel').classList.remove('show');
    document.getElementById('welcomeNotif').classList.remove('show');
    document.getElementById('loginPass').value = '';
    document.getElementById('appWrap').classList.remove('active');
    document.getElementById('authPage').classList.remove('hidden');
    window.scrollTo(0, 0);
}
function checkAuth() {
    let session = localStorage.getItem('vip_session');
    if (session) return verifyDev().finally(() => enterApp(session, true));
    document.getElementById('authPage').classList.remove('hidden');
    return Promise.resolve();
}
function enterApp(username, restore) {
    document.getElementById('authPage').classList.add('hidden');
    document.getElementById('appWrap').classList.add('active');
    document.getElementById('devUser').textContent = username;
    document.getElementById('sbName').textContent = username;
    document.getElementById('profName').textContent = username;
    let initial = username.charAt(0).toUpperCase();
    document.getElementById('sbAvatar').textContent = initial;
    document.getElementById('profAvatar').textContent = initial;
    updateDeviceInfo();
    applyRole();
    applyCustomTools();
    applyMusicList();
    syncPublicData().catch(()=>{});
    applyBanner();
    applyNotif();
    if (restore) restoreNav(); else { clearNav(); showPage('homePage', true); }
    resetViewport();
    showWelcomeNotif();
}
// Setelah login keyboard HP bisa nyisain offset viewport -> celah di atas header.
// Tutup keyboard (blur) lalu paksa scroll balik ke 0 tanpa animasi.
function resetViewport() {
    if (document.activeElement && document.activeElement.blur) document.activeElement.blur();
    const go = () => window.scrollTo(0, 0);
    go(); requestAnimationFrame(go); setTimeout(go, 150); setTimeout(go, 450);
}
function updateDeviceInfo() {
    let ua = navigator.userAgent;
    let device = 'Desktop';
    if (/Android/i.test(ua)) device = 'Android';
    else if (/iPhone|iPad|iPod/i.test(ua)) device = 'iOS';
    else if (/Windows/i.test(ua)) device = 'Windows';
    else if (/Mac/i.test(ua)) device = 'macOS';
    else if (/Linux/i.test(ua)) device = 'Linux';
    document.getElementById('devDevice').textContent = device;
    document.getElementById('profDevice').textContent = device;
    if (navigator.getBattery) {
        navigator.getBattery().then(b => {
            let level = Math.round(b.level * 100);
            let text = level + '% ' + (b.charging ? '⚡' : '');
            document.getElementById('devBattery').textContent = text;
            document.getElementById('profBattery').textContent = text;
        }).catch(() => {});
    }
}

const F = (k, l, ph, o = {}) => ({ k, l, ph, ...o });
const SX = 'https://api.synoxcloud.xyz', NX = 'https://api.nexadev.my.id', NX2 = 'https://apii.nexadev.my.id', NR = 'https://api.nexray.eu.cc';
const urlF = (ph) => F('url', 'URL', ph || 'https://...');

const TOOLS = {
    instagram: { cat: 'downloader', icon: 'fa-brands fa-instagram', name: 'Instagram', desc: 'Download video & foto', badge: 'HD', base: NR + '/downloader/instagram', fields: [urlF('Link Instagram')] },
    tiktok: { cat: 'downloader', icon: 'fa-brands fa-tiktok', name: 'TikTok', desc: 'No watermark', badge: 'MP4', base: 'https://api-faa.my.id/faa/tiktok', fields: [urlF('Link TikTok')] },
    youtube: { cat: 'downloader', icon: 'fa-brands fa-youtube', name: 'YouTube', desc: 'Video & audio', badge: 'MP4/MP3', base: NR + '/downloader/ytmp4', fixed: { resolusi: 720 }, fields: [urlF('Link YouTube')] },
    iqc: { cat: 'maker', icon: 'fa-solid fa-image', name: 'IQC Generator', desc: 'Buat gambar IQC', badge: 'Custom', kind: 'img', base: NR + '/maker/v1/iqc', fixed: { provider: 'Axis', jam: 12, baterai: 65 }, fields: [F('text', 'Teks', 'Teks IQC')] },
    winquotes: { cat: 'maker', icon: 'fa-brands fa-windows', name: 'Windows Quotes', desc: 'Quote ala Windows', badge: 'Meme', kind: 'img', base: 'https://api-nanzz.my.id/docs/api/maker/windows-quotes.php', fields: [F('text', 'Teks', 'Teks quote')] },
    tanyaustadz: { cat: 'maker', icon: 'fa-solid fa-user-tie', name: 'Tanya Ustadz', desc: 'Meme generator', badge: 'Lucu', kind: 'img', base: 'https://api-nanzz.my.id/docs/api/maker/tanyaustadz.php', fields: [F('text', 'Teks', 'Pertanyaan')] },
    sertifikat: { cat: 'maker', icon: 'fa-solid fa-certificate', name: 'Sertifikat Tolol', desc: 'Buat sertifikat lucu', badge: 'New!', kind: 'img', base: 'https://api.siputzx.my.id/api/canvas/sertifikat-tolol', fields: [F('text', 'Nama', 'Nama penerima')] },
    brat: { cat: 'maker', icon: 'fa-solid fa-font', name: 'BRAT Generator', desc: 'Buat teks gaya BRAT', badge: 'New!', special: 'brat', fields: [F('text', 'Teks', 'Teks BRAT')] },
    fakeig: { cat: 'maker', icon: 'fa-brands fa-instagram', name: 'Fake IG', desc: 'Generator fake Instagram', badge: 'New!', special: 'fakeig', fields: [F('username', 'Username', 'username'), F('posts', 'Postingan', '120', { def: '120' }), F('followers', 'Followers', '15.2K', { def: '15.2K' }), F('following', 'Following', '300', { def: '300' }), F('bio', 'Bio', 'Bio singkat')] },
    qr: { cat: 'tools', icon: 'fa-solid fa-qrcode', name: 'QR Generator', desc: 'Buat QR code', badge: 'Instant', kind: 'img', base: 'https://quickchart.io/qr', fixed: { size: 400 }, fields: [F('text', 'Teks / URL', 'Isi QR')] },
    calc: { cat: 'tools', icon: 'fa-solid fa-calculator', name: 'Calculator', desc: 'Hitung cepat', badge: 'Math', special: 'calc', fields: [F('expr', 'Ekspresi', '12*(3+4)')] },
    pwgen: { cat: 'tools', icon: 'fa-solid fa-key', name: 'Password Gen', desc: 'Password aman', badge: 'Secure', special: 'pwgen', fields: [F('len', 'Panjang', '14', { def: '14' })] },
    morse: { cat: 'tools', icon: 'fa-solid fa-broadcast', name: 'Morse Code', desc: 'Konversi morse', badge: 'Audio', special: 'morse', fields: [F('text', 'Teks', 'Teks / kode morse')] },
    bratvid: { cat: 'tools', icon: 'fa-solid fa-film', name: 'BratVid Patrick', desc: 'Video brat Patrick', badge: 'New!', kind: 'video', base: NX2 + '/bratpatrick/video', fields: [F('text', 'Teks', 'hallo gua nexa')] },
    wmp2: { cat: 'tools', icon: 'fa-solid fa-panorama', name: 'WMP2 Canvas 2', desc: 'Pisahkan baris dengan |', badge: 'New!', kind: 'img', base: NX2 + '/wmp2', fields: [F('text', 'Teks (pisah |)', 'ngapain cemburu|kan|cuman sebatas|teman')] },
    susunkata: { cat: 'tools', icon: 'fa-solid fa-spell-check', name: 'Game Susun Kata', desc: 'Tebak kata acak', badge: 'Game', special: 'susun', base: SX + '/games/susun-kata', fixed: { apikey: 'FREE' }, fields: [] },
    fakedev3: { cat: 'tools', icon: 'fa-solid fa-code', name: 'Fake Dev 3', desc: 'Kartu fake developer', badge: 'New!', kind: 'img', base: SX + '/canvas/fakedev-3', fixed: { apikey: 'FREE' }, fields: [F('image', 'URL Gambar', 'https://...jpg'), F('text1', 'Teks 1', 'SAURUS OFFICIAL'), F('text2', 'Teks 2', 'LORDSAURUS')] },
    fakestory: { cat: 'tools', icon: 'fa-solid fa-circle-play', name: 'Fake Story', desc: 'Story palsu', badge: 'New!', kind: 'img', base: SX + '/canvas/fakestory', fixed: { apikey: 'FREE' }, fields: [F('nickname', 'Nickname', 'Saurus'), F('text', 'Teks', 'Haii haloo'), F('pp', 'URL Foto Profil', 'https://...jpg')] },
    spotifycard: { cat: 'tools', icon: 'fa-brands fa-spotify', name: 'Sportif Card', desc: 'Kartu lagu ala Spotify', badge: 'New!', kind: 'img', base: SX + '/canvas/spotifycard', fixed: { apikey: 'FREE' }, fields: [F('title', 'Judul Lagu', 'Bergema sampai selamanya'), F('artist', 'Artis', 'Nadhif Basalamah'), F('cover', 'URL Cover', 'https://...jpg')] },
    wasted: { cat: 'tools', icon: 'fa-solid fa-skull', name: 'Wasted Img', desc: 'Efek WASTED', badge: 'New!', kind: 'img', base: SX + '/canvas/wasted', fixed: { apikey: 'FREE' }, fields: [urlF('URL gambar')] },
    fakeml: { cat: 'tools', icon: 'fa-solid fa-gamepad', name: 'Fake ML', desc: 'Profil Mobile Legends palsu', badge: 'New!', kind: 'img', base: SX + '/canvas/fakeml', fixed: { apikey: 'FREE' }, fields: [F('avatar', 'URL Avatar', 'https://...jpg'), F('username', 'Username', 'Saurus'), F('rank', 'Rank', 'imo', { def: 'imo' }), F('border', 'Border', '16', { def: '16' })] },
    idcarddev: { cat: 'tools', icon: 'fa-solid fa-id-card', name: 'ID Card Dev', desc: 'ID card developer', badge: 'New!', kind: 'img', base: SX + '/canvas/idcard', fixed: { apikey: 'FREE' }, fields: [F('name', 'Nama', 'Saurus'), F('title', 'Title', 'Creator'), F('script', 'Script', 'Api synox'), F('contact', 'Kontak', 'https://t.me/lordsaurus')] },
    getsource: { cat: 'vip', icon: 'fa-solid fa-file-zipper', name: 'GET SOURCE CODE', desc: 'Ambil source code HTML website', badge: 'ZIP', dl: 'zip', base: NR + '/tools/webtozip', note: 'Ambil source code HTML dari sebuah website (hasil ZIP).', fields: [urlF('https://example.com')] },
    pixel: { cat: 'vip', icon: 'fa-solid fa-border-all', name: 'Image To Pixel Art', desc: 'Ubah gambar jadi pixel art', badge: 'Pixel', kind: 'img', base: NX2 + '/pixel', fields: [urlF('URL gambar'), F('pixel', 'Ukuran pixel', '5', { def: '5' })] },
    ampreset: { cat: 'vip', icon: 'fa-solid fa-sliders', name: 'AM Preset', desc: 'Preset dari link TikTok', badge: 'VIP', base: NX + '/api/ampreset', fields: [urlF('Link TikTok')] },
    ambulk: { cat: 'vip', icon: 'fa-solid fa-layer-group', name: 'AM Bulk', desc: 'Order AM massal', badge: 'VIP', captcha: true, proxy: '/api/nx', pid: 'ambulk', fields: [F('amount', 'Jumlah', '1', { def: '1' }), F('orderId', 'Order ID', 'nexachan', { def: 'nexachan' })] },
    roblox: { cat: 'vip', icon: 'fa-solid fa-cube', name: 'Roblox Stalker', desc: 'Cek profil Roblox', badge: 'VIP', base: NX + '/api/roblox', fields: [F('username', 'Username Roblox', 'Linkmon99')] },
    ffstalk: { cat: 'vip', icon: 'fa-solid fa-fire', name: 'Free Fire Stalker', desc: 'Cek akun Free Fire', badge: 'VIP', base: NX + '/api/ff', fields: [F('id', 'ID Free Fire', '7606762852')] },
    wink: { cat: 'vip', icon: 'fa-solid fa-wand-magic-sparkles', name: 'Wink HD Image', desc: 'HD-kan gambar', badge: 'HD', kind: 'img', base: NX + '/api/wink', fields: [urlF('URL gambar')] },
    rch: { cat: 'vip', icon: 'fa-solid fa-face-smile', name: 'React Saluran', desc: 'React postingan saluran WA', badge: 'VIP', captcha: true, proxy: '/api/rch', fields: [urlF('Link postingan saluran'), F('reaction', 'Reaction', '👍', { def: '👍' })] },
    amprem: { cat: 'vip', icon: 'fa-solid fa-envelope-circle-check', name: 'AM Prem', desc: 'AM Send & AM Verif', badge: 'VIP', fields: [F('email', 'Email', 'user@email.com'), F('link', 'Link verifikasi (untuk Verif)', 'https://...')], captcha: true, proxy: '/api/nx', actions: [{ label: 'AM Send', icon: 'fa-paper-plane', pid: 'amsend', use: ['email'] }, { label: 'AM Verif', icon: 'fa-circle-check', pid: 'amverif', use: ['email', 'link'] }] },
    bypass: { cat: 'vip', icon: 'fa-solid fa-forward', name: 'Skip Link Bypass', desc: 'Bypass shortlink', badge: 'VIP', captcha: true, proxy: '/api/nx', pid: 'bypass', fields: [urlF('Link shortlink')] },
    tiktokview: { cat: 'vip', icon: 'fa-solid fa-eye', name: 'TikTok View Boost', desc: 'Tambah views TikTok', badge: 'VIP', captcha: true, proxy: '/api/nx', pid: 'tiktokview', fields: [urlF('Link TikTok'), F('qty', 'Jumlah', '1000', { def: '1000' })] },
    channelmem: { cat: 'vip', icon: 'fa-solid fa-users', name: 'Suntik Pengikut Saluran WA', desc: 'Tambah pengikut saluran', badge: 'VIP', captcha: true, proxy: '/api/nx', pid: 'channelmem', fields: [urlF('Link saluran WA'), F('quantity', 'Jumlah', '100', { def: '100' })] },
    web2app: { cat: 'vip', icon: 'fa-solid fa-mobile-screen', name: 'WEB2APP', desc: 'Ubah website jadi APK', badge: 'APK', dl: 'apk', base: SX + '/tools/web2apkv3', fixed: { apikey: 'FREE' }, fields: [urlF('https://example.com'), F('appName', 'Nama App', 'MyApp', { def: 'MyApp' }), F('packageName', 'Package Name', 'com.example.myapp', { def: 'com.example.myapp' }), F('icon', 'URL Icon (png)', 'https://example.com/icon.png'), F('versionName', 'Version Name', '1.0', { def: '1.0' }), F('versionCode', 'Version Code', '1', { def: '1' }), F('splashType', 'Splash', '', { opts: ['image', 'none'] }), F('orientation', 'Orientasi', '', { opts: ['auto', 'portrait', 'landscape'] })] },
    removebg: { cat: 'vip', icon: 'fa-solid fa-eraser', name: 'Remove BG', desc: 'Hapus background', badge: 'AI', kind: 'img', base: NR + '/tools/removebg', fields: [urlF('URL gambar')] },
    enhancer: { cat: 'vip', icon: 'fa-solid fa-magic', name: 'Image Enhancer', desc: 'Tingkatkan kualitas', badge: 'HD', kind: 'img', base: NX + '/api/wink', fields: [urlF('URL gambar')] },
    fakeff: { cat: 'vip', icon: 'fa-solid fa-fire', name: 'Fake FF', desc: 'Free Fire simulator', badge: 'New!', kind: 'img', base: NX + '/maker/fakeff', fields: [F('nickname', 'Nickname', 'Nickname FF')] },
    deface: { cat: 'vip', icon: 'fa-solid fa-skull', name: 'Deface Generator', desc: 'Generate halaman kunci web palsu (simulasi)', badge: 'HTML', special: 'deface', note: 'Simulasi/kw halaman "terkunci" (bukan virus sungguhan). Isi nama & gambar, lalu generate.', fields: [F('dname', 'Nama Deface', 'Nama kamu'), F('dimg', 'URL Gambar Deface', 'https://...jpg')] },
    nglspam: { cat: 'vip', icon: 'fa-solid fa-comment-dots', name: 'SPAMMER NGL', desc: 'Spam pesan NGL', badge: 'VIP', base: NX + '/tools/nglspam/', fields: [urlF('https://ngl.link/username'), F('pesan', 'Pesan', 'hallo', { def: 'hallo' }), F('jumlah', 'Jumlah', '2', { def: '2' })] },
    nonton18: { cat: 'vip', icon: 'fa-solid fa-eye-slash', name: 'NONTON VD 18+', desc: 'Join saluran', badge: 'VIP', link: 'https://whatsapp.com/channel/0029Vb7pVWHA89Mm5jVvkI3L' },
    deployhtml: { cat: 'vip', icon: 'fa-solid fa-cloud-arrow-up', name: 'DEPLOY HTML TO WEB', desc: 'Deploy HTML ke Vercel', badge: 'Vercel', special: 'deploy', fields: [F('html', 'HTML Code', '<h1>Hello</h1>'), F('projectName', 'Nama Project', 'my-project', { def: 'my-project' })] },
    spambottele: { cat: 'vip', icon: 'fa-solid fa-robot', name: 'SPAMMER BOT TELEGRAM', desc: 'Spam pesan ke bot Telegram', badge: 'VIP', special: 'spambot', fields: [F('token', 'Token Bot', '123456:ABC-DEF...'), F('chatId', 'Chat ID Target', '123456789'), F('pesan', 'Pesan', 'Hallo'), F('jumlah', 'Jumlah Spam', '5', { def: '5' })] },
    zxvai: { cat: 'vip', icon: 'fa-solid fa-robot', name: 'ZxVAI', desc: 'AI tools & APK', link: 'https://zxvaiapk.netlify.app/' },
    fotolink: { cat: 'vip', icon: 'fa-solid fa-image', name: 'Foto To Link', desc: 'Upload & share', link: 'https://pixvault-bykz.netlify.app/' },
    handtrack: { cat: 'vip', icon: 'fa-solid fa-hand', name: 'Hand Trick', desc: 'Track tangan interaktif', link: 'https://kaze-hand-track.netlify.app/' },
    phising: { cat: 'vip', icon: 'fa-solid fa-camera', name: 'Phising Get Foto', desc: 'Ambil foto target', link: 'https://spoiler-project.netlify.app/' },
    interaktif: { cat: 'vip', icon: 'fa-solid fa-hand-peace', name: 'Interaktif Hand', desc: 'Hand gesture interaktif', link: 'https://interaktif-hand.netlify.app/' },
    unband: { cat: 'vip', icon: 'fa-solid fa-phone-slash', name: 'Unband WA', desc: 'Unban WhatsApp', link: 'https://unband-byzxv.netlify.app/' },
    fakecall: { cat: 'vip', icon: 'fa-solid fa-phone', name: 'Fake Call', desc: 'Simulasi panggilan palsu', link: 'https://fc-kzy.netlify.app/' },
    anonychat: { cat: 'vip', icon: 'fa-solid fa-user-secret', name: 'Anony Chat', desc: 'Chat anonim (segera hadir)', badge: 'Soon', disabled: true },
};

// ================= STATE =================
let currentCat = 'all';
let customTools = {};
function allTools() { return Object.assign({}, TOOLS, customTools); }

// ================= CUSTOM TOOLS (DEV) =================
function applyCustomTools() {
    try { customTools = JSON.parse(localStorage.getItem('nx_custom_tools') || '{}'); } catch { customTools = {}; }
}
function doAddTool() {
    if (getRole() !== 'DEV') return toast('Khusus DEV!');
    const name = document.getElementById('atName').value.trim();
    const cat = document.getElementById('atCat').value;
    const api = document.getElementById('atApi').value.trim();
    const key = document.getElementById('atKey').value.trim();
    const st = document.getElementById('atStatus');
    if (!name || !api) { st.style.color = '#dc2626'; st.textContent = '⚠️ Nama & API wajib diisi!'; return; }
    const id = 'custom_' + name.toLowerCase().replace(/[^a-z0-9]+/g, '_').slice(0, 30) + '_' + Date.now();
    let fields = [{k:'q',l:'Input',ph:'Masukkan nilai'}];
    try { const raw=document.getElementById('atFields').value.trim(); if(raw) { const parsed=JSON.parse(raw); if(!Array.isArray(parsed)||parsed.some(f=>!f.k||!f.l)) throw new Error(); fields=parsed.slice(0,12).map(f=>({k:String(f.k).replace(/[^a-zA-Z0-9_-]/g,'').slice(0,40),l:String(f.l).slice(0,80),ph:String(f.ph||'').slice(0,180),def:f.def||'',opts:Array.isArray(f.opts)?f.opts.slice(0,30):undefined})); } } catch { st.style.color='#dc2626'; st.textContent='Format Input API harus JSON array yang valid.'; return; }
    const icon=document.getElementById('atIcon').value.trim() || 'fa-solid fa-cube';
    const desc=document.getElementById('atDesc').value.trim() || 'Tools tambahan';
    const method=document.getElementById('atMethod').value;
    let actions=[];try{const raw=document.getElementById('atActions').value.trim();if(raw){const a=JSON.parse(raw);if(!Array.isArray(a))throw new Error();actions=a.slice(0,8).map(x=>({label:String(x.label||'Jalankan').slice(0,50),icon:String(x.icon||'fa-bolt').slice(0,60),base:String(x.base||api),use:Array.isArray(x.use)?x.use:fields.map(f=>f.k),fixed:key?{apikey:key}:{} }));}}catch{st.style.color='#dc2626';st.textContent='Format Tombol API harus JSON array yang valid.';return;}
    customTools[id] = { cat, icon, name, desc, badge: 'Custom', base: api, method, fields, actions: actions.length ? actions : undefined, fixed: key ? { apikey: key } : {} };
    localStorage.setItem('nx_custom_tools', JSON.stringify(customTools));
    saveToolToDatabase(id, customTools[id]).catch(e=>toast('Tools tersimpan di perangkat ini; database: '+e.message));
    st.style.color = '#22c55e'; st.textContent = '✅ Tools "' + name + '" berhasil ditambahkan!';
    document.getElementById('atName').value = ''; document.getElementById('atApi').value = ''; document.getElementById('atKey').value = ''; document.getElementById('atDesc').value=''; document.getElementById('atIcon').value=''; document.getElementById('atFields').value=''; document.getElementById('atActions').value='';
    renderGrid('popularGrid', popularTools());
    if (document.getElementById('toolsPage').classList.contains('active')) renderCategory(currentCat);
}

// ================= MUSIC =================
const DEFAULT_MUSIC = []; // Tidak ada lagu NEXORA bawaan; playlist dimulai dari Lagu 1 yang ditambahkan admin.
let musicList = [];
let musicIdx = 0;
let musicAuto = false;
const audioEl = new Audio();
audioEl.addEventListener('ended', () => { if (musicAuto) mNext(); else mStop(); });

function applyMusicList() {
    let extra = [];
    try { extra = JSON.parse(localStorage.getItem('nx_music') || '[]'); } catch {}
    musicList = DEFAULT_MUSIC.concat(extra);
    musicAuto = localStorage.getItem('nx_music_auto') === '1';
    renderMusicManageList();
}
function renderMusicManageList() {
    const box = document.getElementById('musicList');
    if (!box) return;
    box.innerHTML = musicList.map((m, i) => i < DEFAULT_MUSIC.length ? '' :
        `<div style="display:flex;justify-content:space-between;align-items:center;padding:8px 0;border-bottom:1px solid var(--border-color);font-size:.75rem">
            <span>${m.name}</span>
            <button onclick="removeMusic(${i})" style="background:none;border:none;color:#dc2626;cursor:pointer"><i class="fas fa-trash"></i></button>
        </div>`).join('');
}
function removeMusic(i) {
    const extra = musicList.slice(DEFAULT_MUSIC.length).filter((_, idx) => idx + DEFAULT_MUSIC.length !== i);
    localStorage.setItem('nx_music', JSON.stringify(extra));
    applyMusicList();
}
function doAddMusic() {
    if (getRole() !== 'DEV') return toast('Khusus DEV!');
    const name = document.getElementById('msName').value.trim();
    const url = document.getElementById('msUrl').value.trim();
    const st = document.getElementById('msStatus');
    if (!name || !url) { st.style.color = '#dc2626'; st.textContent = '⚠️ Nama & URL wajib diisi!'; return; }
    let extra = []; try { extra = JSON.parse(localStorage.getItem('nx_music') || '[]'); } catch {}
    extra.push({ name, url });
    localStorage.setItem('nx_music', JSON.stringify(extra));
    saveMusicToDatabase(name,url).catch(e=>toast('Lagu tersimpan lokal; database: '+e.message));
    st.style.color = '#22c55e'; st.textContent = '✅ Musik ditambahkan!';
    document.getElementById('msName').value = ''; document.getElementById('msUrl').value = '';
    applyMusicList();
}
function mToggleUI() { document.getElementById('musicPanel').classList.toggle('show'); }
function mLoad(i) {
    if (!musicList.length) { toast('Belum ada lagu. Admin perlu menambahkan Lagu 1.'); return; }
    musicIdx = (i + musicList.length) % musicList.length;
    const t = musicList[musicIdx];
    audioEl.src = t.url;
    document.getElementById('mTrackName').textContent = t.name;
}
function mPlayPause() {
    if (!audioEl.src) mLoad(musicIdx);
    if (audioEl.paused) { audioEl.play().catch(() => toast('Gagal memutar musik')); document.getElementById('mPlayIcon').className = 'fas fa-pause'; }
    else { audioEl.pause(); document.getElementById('mPlayIcon').className = 'fas fa-play'; }
}
function mPrev() { mLoad(musicIdx - 1); audioEl.play().catch(() => {}); document.getElementById('mPlayIcon').className = 'fas fa-pause'; }
function mNext() { mLoad(musicIdx + 1); audioEl.play().catch(() => {}); document.getElementById('mPlayIcon').className = 'fas fa-pause'; }
function mStop() { audioEl.pause(); audioEl.currentTime = 0; document.getElementById('mPlayIcon').className = 'fas fa-play'; }
function mToggleAuto() {
    musicAuto = !musicAuto;
    localStorage.setItem('nx_music_auto', musicAuto ? '1' : '0');
    document.getElementById('mAutoBtn').style.color = musicAuto ? 'var(--primary)' : '';
    toast(musicAuto ? 'Auto ganti musik: ON' : 'Auto ganti musik: OFF');
}

async function syncPublicData(){try{const r=await fetch('/api/admin-data?action=public',{cache:'no-store'});const d=await r.json();if(!r.ok||!d.ok)return;for(const row of (d.tools||[])){const c=row.config||{};if(c.key||row.id)customTools[c.key||row.id]={...c,maintenance:row.maintenance,maintenance_message:row.maintenance_message};}musicList=(d.music||[]).map((m,i)=>({id:m.id,name:m.name||('Lagu '+(i+1)),url:m.url}));renderMusicTrackList();renderMusicManageList();renderGrid('popularGrid',popularTools());if(document.getElementById('toolsPage').classList.contains('active'))renderCategory(currentCat);}catch{}}
function renderMusicTrackList(){const box=document.getElementById('mTrackList');if(!box)return;box.innerHTML=musicList.map((m,i)=>`<button style="display:block;width:100%;text-align:left;padding:7px;border:0;background:transparent;color:inherit" onclick="mLoad(${i});mPlayPause()">${i+1}. ${escapeHtml(m.name)}</button>`).join('');}
// ================= SUPABASE ADMIN SYNC =================
async function adminApi(action, payload={}, method='POST') {
  const token=localStorage.getItem('vip_dev_token');
  const r=await fetch('/api/admin-data'+(method==='GET'?'?action='+encodeURIComponent(action):''),{method,headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},...(method==='POST'?{body:JSON.stringify({action,...payload})}:{})});
  const d=await r.json().catch(()=>({})); if(!r.ok||!d.ok) throw new Error(d.message||'Permintaan database gagal'); return d;
}
async function saveToolToDatabase(id,tool){ return adminApi('saveTool',{tool:{id,key:id,name:tool.name,category:tool.cat,...tool}}); }
async function saveMusicToDatabase(name,url){ return adminApi('saveMusic',{name,url}); }
async function loadAdminStats(){ try{const d=await adminApi('stats',{},'GET');document.getElementById('accountTotal').textContent=d.accounts;document.getElementById('toolTotal').textContent=d.tools;const list=await adminApi('public',{},'GET');renderAdminToolList(list.tools||[],'devToolList',true);}catch(e){toast(e.message);} }
async function loadAdminTools(){try{const d=await adminApi('public',{},'GET');renderAdminToolList(d.tools||[],'adminToolList',false);}catch(e){toast(e.message);}}
function renderAdminToolList(rows,target,canDelete){const box=document.getElementById(target);if(!box)return;if(!rows.length){box.textContent='Belum ada tools di database.';return;}box.innerHTML=rows.map(r=>{const c=r.config||{};const id=String(r.id);const safe=id.replace(/[^a-zA-Z0-9_-]/g,'');return `<div class="device-card" style="margin:8px 0"><b>${escapeHtml(r.name||c.name||id)}</b><p class="small-note">${r.maintenance?'Maintenance: '+escapeHtml(r.maintenance_message||'Tools sedang maintenance'):'Status: Aktif'}</p><label class="f-label">Pesan maintenance</label><input class="v-input" id="maint_${safe}" value="${escapeHtml(r.maintenance_message||'Tools sedang maintenance')}"/><div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px"><button class="v-btn" style="width:auto;flex:1" onclick="setToolMaintenance('${safe}',true)">Kunci sementara</button><button class="v-btn" style="width:auto;flex:1" onclick="setToolMaintenance('${safe}',false)">Buka kunci</button>${canDelete?`<button class="v-btn" style="width:auto;background:#b91c1c" onclick="deleteDatabaseTool('${safe}')">Hapus</button>`:''}</div></div>`}).join('');}
async function setToolMaintenance(id,enabled){try{const msg=document.getElementById('maint_'+id)?.value||'Tools sedang maintenance';await adminApi('setMaintenance',{id,enabled,message:msg});toast(enabled?'Maintenance diaktifkan.':'Tools dibuka kembali.');loadAdminTools();loadAdminStats();}catch(e){toast(e.message);}}
async function deleteDatabaseTool(id){if(!confirm('Hapus tools ini dari database?'))return;try{await adminApi('deleteTool',{id});delete customTools[id];localStorage.setItem('nx_custom_tools',JSON.stringify(customTools));toast('Tools database dihapus.');renderGrid('popularGrid',popularTools());loadAdminStats();loadAdminTools();}catch(e){toast(e.message);}}

// ================= BANNER =================
function applyBanner() {
    let b = {}; try { b = JSON.parse(localStorage.getItem('nx_banner') || '{}'); } catch {}
    if (b.bg) document.getElementById('bgVideo').src = b.bg;
    if (b.video) document.getElementById('bannerVideo').src = b.video;
}
function doSaveBanner() {
    if (getRole() !== 'DEV') return toast('Khusus DEV!');
    const video = document.getElementById('bnVideo').value.trim();
    const bg = document.getElementById('bnBg').value.trim();
    const st = document.getElementById('bnStatus');
    const data = {}; if (video) data.video = video; if (bg) data.bg = bg;
    localStorage.setItem('nx_banner', JSON.stringify(data));
    st.style.color = '#22c55e'; st.textContent = '✅ Banner disimpan!';
    applyBanner();
}

// ================= NOTIF / WELCOME =================
function applyNotif() {
    let n = {}; try { n = JSON.parse(localStorage.getItem('nx_notif') || '{}'); } catch {}
    const box = document.getElementById('welcomeNotif');
    const title = box.querySelector('h5');
    const text = document.getElementById('welcomeText');
    if (n.on && n.text) {
        if (n.title) title.textContent = n.title;
        text.textContent = n.text;
        if (n.link) text.insertAdjacentHTML('afterend', `<a href="${n.link}" target="_blank" style="color:var(--primary-light);font-weight:600;display:inline-block;margin-top:6px;font-size:.72rem">${n.linkText || 'Buka Link'} <i class="fas fa-arrow-up-right-from-square"></i></a>`);
    } else {
        text.textContent = 'Selamat datang di dunia tools premium gratis. Jangan lupa follow saluran biar update!';
    }
    document.getElementById('nfOn').checked = !!n.on;
    document.getElementById('nfTitle').value = n.title || '';
    document.getElementById('nfText').value = n.text || '';
    document.getElementById('nfLink').value = n.link || '';
    document.getElementById('nfLinkText').value = n.linkText || '';
}
function doSaveNotif() {
    if (getRole() !== 'DEV') return toast('Khusus DEV!');
    const data = {
        on: document.getElementById('nfOn').checked,
        title: document.getElementById('nfTitle').value.trim(),
        text: document.getElementById('nfText').value.trim(),
        link: document.getElementById('nfLink').value.trim(),
        linkText: document.getElementById('nfLinkText').value.trim(),
    };
    localStorage.setItem('nx_notif', JSON.stringify(data));
    document.getElementById('nfStatus').style.color = '#22c55e';
    document.getElementById('nfStatus').textContent = '✅ Notifikasi disimpan!';
}
function showWelcomeNotif() {
    if (sessionStorage.getItem('nx_wn_closed')) return;
    document.getElementById('welcomeNotif').classList.add('show');
}
function closeWelcomeNotif() {
    document.getElementById('welcomeNotif').classList.remove('show');
    sessionStorage.setItem('nx_wn_closed', '1');
}

// ================= SIDEBAR =================
function toggleSidebar() {
    document.getElementById('sidebar').classList.toggle('open');
    document.getElementById('sbOverlay').classList.toggle('show');
}
function closeSidebar() {
    document.getElementById('sidebar').classList.remove('open');
    document.getElementById('sbOverlay').classList.remove('show');
}
document.addEventListener('DOMContentLoaded', () => {
    document.getElementById('sbOverlay').addEventListener('click', closeSidebar);
    document.querySelectorAll('.sb-item[data-page]').forEach(el => el.addEventListener('click', () => { showPage(el.dataset.page); closeSidebar(); }));
    document.querySelectorAll('.nav-item[data-page]').forEach(el => el.addEventListener('click', () => showPage(el.dataset.page)));
    document.getElementById('searchInput').addEventListener('input', e => { renderCategory(currentCat, e.target.value); });
    document.querySelectorAll('.category-tab[data-category]').forEach(el => el.addEventListener('click', () => {
        document.querySelectorAll('.category-tab').forEach(t => t.classList.remove('active'));
        el.classList.add('active'); currentCat = el.dataset.category; saveNav({ cat: currentCat });
        renderCategory(currentCat, document.getElementById('searchInput').value);
    }));
    document.getElementById('saranKirimBtn').addEventListener('click', doSendSaran);
});


// ================= INGAT POSISI HALAMAN (biar refresh gak balik ke beranda) =================
const NAV_KEY = 'nx_nav';
const DEV_ONLY_PAGES = ['upgradePage', 'addToolPage', 'notifSettingsPage', 'musicSettingsPage', 'bannerSettingsPage', 'devManagePage', 'adminToolsPage'];
function saveNav(patch) {
    try {
        let n = {}; try { n = JSON.parse(sessionStorage.getItem(NAV_KEY) || '{}'); } catch {}
        sessionStorage.setItem(NAV_KEY, JSON.stringify(Object.assign(n, patch)));
    } catch {}
}
function clearNav() { try { sessionStorage.removeItem(NAV_KEY); } catch {} }
function restoreNav() {
    let n = {};
    try { n = JSON.parse(sessionStorage.getItem(NAV_KEY) || '{}'); } catch {}
    let page = n.page && document.getElementById(n.page) ? n.page : 'homePage';
    // halaman khusus DEV cuma boleh dipulihkan kalau role-nya memang DEV
    if (DEV_ONLY_PAGES.includes(page) && getRole() !== 'DEV') page = 'homePage';
    if (n.cat) {
        currentCat = n.cat;
        document.querySelectorAll('.category-tab').forEach(t => t.classList.toggle('active', t.dataset.category === currentCat));
    }
    showPage(page, true);
    if (n.tool && allTools()[n.tool]) openTool(n.tool);
}

// ================= PAGE NAV =================
function showPage(id, instant) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    const target = document.getElementById(id);
    if (target) target.classList.add('active');
    document.querySelectorAll('.header-nav a').forEach(a => a.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(a => a.classList.remove('active'));
    document.querySelectorAll('.sb-item').forEach(a => a.classList.remove('active'));
    const map = { homePage: 'navHome', toolsPage: 'navTools', profilePage: 'navProfile' };
    if (map[id] && document.getElementById(map[id])) document.getElementById(map[id]).classList.add('active');
    document.querySelectorAll(`[data-page="${id}"]`).forEach(el => el.classList.add('active'));
    if (id === 'toolsPage') renderCategory(currentCat);
    saveNav({ page: id, tool: null });
    window.scrollTo({ top: 0, behavior: instant ? 'auto' : 'smooth' });
}

// ================= TOOLS GRID =================
function popularTools() {
    const all = allTools();
    return Object.keys(all).slice(0, 8).map(k => ({ key: k, ...all[k] }));
}
function renderGrid(containerId, list) {
    const box = document.getElementById(containerId);
    if (!box) return;
    if (!list.length) { box.innerHTML = '<p style="grid-column:1/-1;text-align:center;color:var(--text-muted);padding:20px 0;font-size:.8rem">Tidak ada tools ditemukan.</p>'; return; }
    box.innerHTML = list.map(t => `
        <div class="tools-card" onclick="openTool('${t.key}')">
            <i class="${t.icon} icon"></i>
            <h4>${t.name}</h4>
            <p>${t.desc || ''}</p>
            ${t.badge ? `<span class="badge">${t.badge}</span>` : ''}
            <i class="fas fa-arrow-right arrow"></i>
        </div>`).join('');
}
function renderCategory(cat, q) {
    const all = allTools();
    q = (q || '').toLowerCase().trim();
    const list = Object.keys(all)
        .map(k => ({ key: k, ...all[k] }))
        .filter(t => (cat === 'all' || t.cat === cat) && (!q || t.name.toLowerCase().includes(q) || (t.desc || '').toLowerCase().includes(q)));
    renderGrid('toolsContainer', list);
}

// ================= TOOL VIEWER / ENGINE =================
let activeToolKey = null;
function openTool(key) {
    const all = allTools();
    const t = all[key];
    if (!t) return;
    if (t.disabled) return toast('Tools ini belum tersedia, nantikan update berikutnya!');
    if (t.maintenance) return toast(t.maintenance_message || 'Tools sedang maintenance.');
    if (t.maintenance) return toast(t.maintenance_message || 'Tools sedang maintenance.'); // VIP tidak dikunci oleh role
    if (t.link) { window.open(t.link, '_blank', 'noopener'); return; }
    activeToolKey = key;
    saveNav({ tool: key });
    const fields = t.fields || [];
    const body = document.getElementById('toolViewerBody');
    body.innerHTML = `
        <h2><i class="${t.icon}"></i>${t.name}</h2>
        ${t.note ? `<p class="small-note" style="margin-bottom:12px">${t.note}</p>` : ''}
        <div id="tvFields">
            ${fields.map(f => `
                <label class="f-label">${f.l}</label>
                ${f.opts ? `<select class="v-select" id="tvf_${f.k}">${f.opts.map(o => `<option value="${o}">${o}</option>`).join('')}</select>`
                         : `<input class="v-input" id="tvf_${f.k}" placeholder="${f.ph || ''}" value="${f.def || ''}">`}
            `).join('')}
        </div>
        ${t.captcha ? '<div id="tvCaptcha" class="captcha-box"></div>' : ''}
        ${t.actions
            ? `<div style="display:flex;gap:8px;flex-wrap:wrap">${t.actions.map((a, i) => `<button class="v-btn" style="width:auto;flex:1" onclick="runTool('${key}', ${i})"><i class="${a.icon}"></i> ${a.label}</button>`).join('')}</div>`
            : `<button class="v-btn" onclick="runTool('${key}')"><i class="fas fa-bolt"></i> Jalankan</button>`}
        <div class="result-box" id="tvResult" style="display:none"></div>
    `;
    document.getElementById('toolViewer').classList.add('active');
    if (t.captcha) mountCaptcha();
}
function closeTool() {
    document.getElementById('toolViewer').classList.remove('active'); activeToolKey = null;
    saveNav({ tool: null });
    if (tsWidgetId !== null && window.turnstile) { try { turnstile.remove(tsWidgetId); } catch {} }
    tsWidgetId = null;
}

function readFields(fields) {
    const out = {};
    fields.forEach(f => {
        const el = document.getElementById('tvf_' + f.k);
        if (!el) return;
        out[f.k] = el.value.trim() || f.def || '';
    });
    return out;
}
function setResult(html) {
    const box = document.getElementById('tvResult');
    box.style.display = 'block';
    box.innerHTML = html;
}
function buildUrl(base, params) {
    const qs = new URLSearchParams();
    Object.entries(params).forEach(([k, v]) => { if (v !== undefined && v !== '') qs.append(k, v); });
    const sep = base.includes('?') ? '&' : '?';
    return qs.toString() ? base + sep + qs.toString() : base;
}

async function runTool(key, actionIdx) {
    const t = allTools()[key];
    if (!t) return;
    const fields = t.fields || [];
    const values = readFields(fields);
    for (const f of fields) {
        if (!f.opts && !values[f.k]) return toast('Isi dulu: ' + f.l);
    }

    if (t.captcha) {
        if (t.pid || t.actions) {
            const action = (t.actions && actionIdx !== undefined) ? t.actions[actionIdx] : null;
            const pid = action ? action.pid : t.pid;
            if (!pid) return;
            const params = {};
            (action && action.use ? action.use : Object.keys(values)).forEach(k => { params[k] = values[k]; });
            return runCaptchaTool(t, { pid, params });
        }
        return runCaptchaTool(t, values);
    }
    if (t.special) return runSpecial(t.special, t, values);

    let base = t.base, fixed = t.fixed || {};
    if (t.actions && actionIdx !== undefined) {
        const action = t.actions[actionIdx];
        base = action.base;
        const used = {};
        (action.use || []).forEach(k => used[k] = values[k]);
        Object.assign(used, action.fixed || {});
        return runGeneric(t, base, used);
    }
    runGeneric(t, base, Object.assign({}, values, fixed));
}

function runGeneric(t, base, params) {
    setResult('<i class="fas fa-circle-notch spin"></i> Memproses...');
    const url = buildUrl(base, params);
    if (t.kind === 'img') {
        setResult(`<img src="${url}" onerror="this.closest('.result-box').innerHTML='❌ Gagal mengambil hasil.'" alt="result"><br><a class="v-btn" style="margin-top:10px" href="${url}" target="_blank" download><i class="fas fa-download"></i> Download</a>`);
        return;
    }
    if (t.kind === 'video') {
        setResult(`<video src="${url}" controls autoplay style="width:100%;border-radius:8px"></video>`);
        return;
    }
    if (t.dl) return runDownload(t, url, params);
    const req = t.method === 'POST' ? {method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(params)} : {};
    const requestUrl = t.method === 'POST' ? base : url;
    fetch(requestUrl,req).then(r => r.ok ? r.text() : Promise.reject(r.status)).then(renderApiText).catch(() => setResult('❌ Gagal mengambil hasil dari server. Coba lagi nanti.'));
}

// ================= HASIL FILE (ZIP / APK) =================
function findUrls(o, out, key) {
    out = out || []; key = key || '';
    if (typeof o === 'string') { if (/^https?:\/\//i.test(o)) out.push({ k: key, v: o }); }
    else if (o && typeof o === 'object') for (const k in o) findUrls(o[k], out, k);
    return out;
}
function pickDownload(data, kind) {
    const urls = findUrls(data);
    const ext = kind === 'apk' ? /\.apk(\?|#|$)/i : /\.zip(\?|#|$)/i;
    const hit = urls.find(u => ext.test(u.v))
        || urls.find(u => /download|apk|zip|file/i.test(u.k))
        || urls.find(u => /download|archive/i.test(u.v));
    return hit ? hit.v : '';
}
function runDownload(t, url, params) {
    setResult('<i class="fas fa-circle-notch spin"></i> Memproses... ' + (t.dl === 'apk' ? '(pembuatan APK bisa sampai 1-2 menit)' : '(mohon tunggu)'));
    fetch(url).then(async r => {
        if (!r.ok) throw r.status;
        const ct = r.headers.get('content-type') || '';
        if (/json|text/i.test(ct)) {
            const txt = await r.text();
            let d = null; try { d = JSON.parse(txt); } catch {}
            if (d) return renderDownload(t, d);
            return setResult('<p style="word-break:break-all">' + escapeHtml(txt).slice(0, 1000) + '</p>');
        }
        // server langsung ngirim file (biner)
        const blob = await r.blob();
        const name = t.dl === 'apk' ? ((params && params.appName) || 'app') + '.apk' : 'source-code.zip';
        const obj = URL.createObjectURL(blob);
        renderDownloadCard(t, obj, 'Ukuran file: ' + (blob.size / 1024).toFixed(0) + ' KB', name);
    }).catch(() => setResult('❌ Gagal mengambil hasil dari server. Coba lagi nanti.'));
}
function renderDownload(t, data) {
    const url = pickDownload(data, t.dl);
    if (!url) {
        const msg = data.message || data.msg || data.error || (data.result && data.result.message) || 'Server tidak mengembalikan link file.';
        setResult('<div class="dl-card err"><i class="fas fa-circle-exclamation dl-ic"></i><h3>Gagal membuat file</h3><p class="dl-info">' + escapeHtml(typeof msg === 'string' ? msg : JSON.stringify(msg)) + '</p></div>');
        return;
    }
    const r = (data && data.result) || data || {};
    const bits = [];
    if (r.copiedFilesAmount) bits.push(r.copiedFilesAmount + ' file berhasil diambil');
    if (r.url && typeof r.url === 'string') bits.push(r.url);
    renderDownloadCard(t, url, bits.join(' • '), '');
}
function renderDownloadCard(t, url, info, filename) {
    const isApk = t.dl === 'apk';
    const label = isApk ? 'APK' : 'ZIP';
    setResult(
        '<div class="dl-card">' +
        '<i class="fas ' + (isApk ? 'fa-mobile-screen' : 'fa-file-zipper') + ' dl-ic"></i>' +
        '<h3>' + label + ' siap diunduh</h3>' +
        (info ? '<p class="dl-info">' + escapeHtml(info) + '</p>' : '') +
        '<a class="v-btn" href="' + escapeHtml(url) + '" ' + (filename ? 'download="' + escapeHtml(filename) + '" ' : 'download ') + 'target="_blank" rel="noopener"><i class="fas fa-download"></i> Download ' + label + '</a>' +
        '</div>'
    );
}

function renderApiText(txt) {
    let data; try { data = JSON.parse(txt); } catch { data = null; }
    if (data) {
        const cand = [data.url, data.result, data.data && data.data.url, data.data && data.data.link, data.link, data.access_link];
        const link = cand.find(c => typeof c === 'string' && /^https?:\/\//i.test(c)) || '';
        const msg = data.message || data.msg;
        setResult(`
            ${msg ? `<p style="margin-bottom:8px">${escapeHtml(msg)}</p>` : ''}
            ${link ? `<a class="v-btn" href="${escapeHtml(link)}" target="_blank" rel="noopener"><i class="fas fa-up-right-from-square"></i> Buka Hasil</a>` : ''}
            <pre style="text-align:left;white-space:pre-wrap;word-break:break-all;font-size:11px;margin-top:10px;max-height:240px;overflow:auto">${escapeHtml(JSON.stringify(data, null, 2))}</pre>
        `);
    } else {
        setResult(`<p style="word-break:break-all">${escapeHtml(txt).slice(0, 2000)}</p>`);
    }
}

// ================= CAPTCHA (Cloudflare Turnstile) =================
let tsSiteKey = null, tsWidgetId = null, tsScriptPromise = null;
function loadTurnstile() {
    if (window.turnstile) return Promise.resolve();
    if (tsScriptPromise) return tsScriptPromise;
    tsScriptPromise = new Promise((resolve, reject) => {
        const sc = document.createElement('script');
        sc.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
        sc.async = true; sc.onload = resolve;
        sc.onerror = () => { tsScriptPromise = null; reject(new Error('turnstile')); };
        document.head.appendChild(sc);
    });
    return tsScriptPromise;
}
async function getSiteKey() {
    if (tsSiteKey) return tsSiteKey;
    const r = await fetch('/api/config');
    const d = await r.json();
    tsSiteKey = d.turnstileSiteKey || '';
    return tsSiteKey;
}
async function mountCaptcha() {
    const box = document.getElementById('tvCaptcha');
    if (!box) return;
    box.innerHTML = '<span class="cap-note">Memuat captcha...</span>';
    try {
        const [key] = await Promise.all([getSiteKey(), loadTurnstile()]);
        const now = document.getElementById('tvCaptcha');
        if (!now || !document.getElementById('toolViewer').classList.contains('active')) return;
        if (!key) { now.innerHTML = '<span class="cap-note err">Captcha belum dikonfigurasi (TURNSTILE_SITE_KEY).</span>'; return; }
        now.innerHTML = '';
        tsWidgetId = turnstile.render(now, { sitekey: key, theme: 'dark', action: 'rch' });
    } catch {
        const now = document.getElementById('tvCaptcha');
        if (now) now.innerHTML = '<span class="cap-note err">Gagal memuat captcha. Tutup lalu buka lagi tools ini.</span>';
    }
}
async function runCaptchaTool(t, values) {
    const token = (window.turnstile && tsWidgetId !== null) ? turnstile.getResponse(tsWidgetId) : '';
    if (!token) return toast('Selesaikan captcha dulu!');
    setResult('<i class="fas fa-circle-notch spin"></i> Memproses...');
    try {
        const r = await fetch(t.proxy, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(Object.assign({}, values, { token })) });
        const txt = await r.text();
        if (r.ok) renderApiText(txt);
        else {
            let msg = 'Gagal mengambil hasil dari server.';
            try { msg = JSON.parse(txt).message || msg; } catch {}
            setResult('❌ ' + escapeHtml(msg));
        }
    } catch { setResult('❌ Gagal terhubung ke server. Coba lagi nanti.'); }
    finally { if (window.turnstile && tsWidgetId !== null) { try { turnstile.reset(tsWidgetId); } catch {} } }
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }

// ================= SPECIAL TOOLS =================
function runSpecial(kind, t, values) {
    if (kind === 'calc') return specialCalc(values.expr);
    if (kind === 'pwgen') return specialPwgen(values.len);
    if (kind === 'morse') return specialMorse(values.text);
    if (kind === 'brat') return specialBrat(values.text);
    if (kind === 'fakeig') return specialFakeIg(values);
    if (kind === 'deface') return specialDeface(values);
    if (kind === 'susun') return specialSusun();
    if (kind === 'deploy') return specialDeploy(values);
    if (kind === 'spambot') return setResult('⚠️ Fitur kirim pesan berulang otomatis sengaja tidak dibuatkan di sini karena berpotensi dipakai buat spam/mengganggu orang lain.');
    setResult('⚠️ Tools ini belum diimplementasikan.');
}
function specialCalc(expr) {
    if (!/^[0-9+\-*/().\s%]+$/.test(expr || '')) return setResult('❌ Ekspresi tidak valid. Hanya angka & operator (+ - * / % ( )).');
    try {
        const result = Function('"use strict";return (' + expr + ')')();
        setResult(`<div style="font-size:1.4rem;font-weight:700">${escapeHtml(expr)} = ${result}</div>`);
    } catch (e) { setResult('❌ Ekspresi tidak valid.'); }
}
function specialPwgen(len) {
    len = Math.min(64, Math.max(4, parseInt(len) || 14));
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnpqrstuvwxyz23456789!@#$%&*';
    let pw = ''; const arr = new Uint32Array(len); crypto.getRandomValues(arr);
    for (let i = 0; i < len; i++) pw += chars[arr[i] % chars.length];
    setResult(`<div style="font-family:monospace;font-size:1.05rem;word-break:break-all;background:rgba(255,255,255,.04);padding:10px;border-radius:8px">${pw}</div><button class="v-btn" style="margin-top:10px" onclick="navigator.clipboard.writeText('${pw}');toast('Password disalin!')"><i class="fas fa-copy"></i> Salin</button>`);
}
const MORSE_MAP = { A: '.-', B: '-...', C: '-.-.', D: '-..', E: '.', F: '..-.', G: '--.', H: '....', I: '..', J: '.---', K: '-.-', L: '.-..', M: '--', N: '-.', O: '---', P: '.--.', Q: '--.-', R: '.-.', S: '...', T: '-', U: '..-', V: '...-', W: '.--', X: '-..-', Y: '-.--', Z: '--..', 0: '-----', 1: '.----', 2: '..---', 3: '...--', 4: '....-', 5: '.....', 6: '-....', 7: '--...', 8: '---..', 9: '----.' };
const MORSE_REV = Object.fromEntries(Object.entries(MORSE_MAP).map(([k, v]) => [v, k]));
function specialMorse(text) {
    text = (text || '').trim();
    const looksMorse = /^[.\-/\s]+$/.test(text) && (text.includes('.') || text.includes('-'));
    let out;
    if (looksMorse) out = text.split(' / ').map(w => w.trim().split(' ').map(c => MORSE_REV[c] || '').join('')).join(' ');
    else out = text.toUpperCase().split(' ').map(w => w.split('').map(c => MORSE_MAP[c] || '').join(' ')).join(' / ');
    setResult(`<div style="font-family:monospace;word-break:break-all;background:rgba(255,255,255,.04);padding:10px;border-radius:8px">${escapeHtml(out) || '-'}</div>`);
}
function specialBrat(text) {
    text = (text || 'brat').toLowerCase();
    const canvas = document.createElement('canvas');
    canvas.width = 500; canvas.height = 500;
    const ctx = canvas.getContext('2d');
    ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, 500, 500);
    ctx.fillStyle = '#000'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    let fontSize = 80; ctx.font = `${fontSize}px Arial`;
    const words = text.split(' ');
    let lines = [], line = '';
    words.forEach(w => {
        const test = line ? line + ' ' + w : w;
        if (ctx.measureText(test).width > 420) { lines.push(line); line = w; } else line = test;
    });
    if (line) lines.push(line);
    while (lines.length * fontSize > 420 && fontSize > 24) { fontSize -= 6; ctx.font = `${fontSize}px Arial`; }
    const startY = 250 - ((lines.length - 1) * fontSize) / 2;
    lines.forEach((l, i) => ctx.fillText(l, 250, startY + i * fontSize));
    const data = canvas.toDataURL('image/png');
    setResult(`<img src="${data}" style="max-width:280px;border-radius:8px"><br><a class="v-btn" style="margin-top:10px" href="${data}" download="brat.png"><i class="fas fa-download"></i> Download</a>`);
}
function specialFakeIg(v) {
    setResult(`
    <div style="background:#000;border-radius:12px;padding:16px;text-align:left;max-width:300px;margin:0 auto;font-family:Arial">
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
            <div style="width:50px;height:50px;border-radius:50%;background:linear-gradient(135deg,#f58529,#dd2a7b,#8134af);flex-shrink:0"></div>
            <b style="color:#fff">${escapeHtml(v.username || 'username')}</b>
        </div>
        <div style="display:flex;gap:16px;color:#fff;font-size:.8rem;margin-bottom:8px">
            <span><b>${escapeHtml(v.posts || '0')}</b> Posts</span>
            <span><b>${escapeHtml(v.followers || '0')}</b> Followers</span>
            <span><b>${escapeHtml(v.following || '0')}</b> Following</span>
        </div>
        <div style="color:#ccc;font-size:.78rem">${escapeHtml(v.bio || '')}</div>
    </div>`);
}
function specialDeface(v) {
    const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>Locked</title>
<style>body{margin:0;min-height:100vh;background:#000 url('${v.dimg || ''}') center/cover;display:flex;align-items:center;justify-content:center;font-family:Arial}
.box{background:rgba(0,0,0,.75);color:#fff;padding:40px;border-radius:16px;text-align:center}
h1{color:#ff2d55;letter-spacing:4px}</style></head>
<body><div class="box"><h1>🔒 LOCKED</h1><p>Halaman ini "dikunci" oleh ${escapeHtml(v.dname || 'Anonymous')}</p><p style="opacity:.6;font-size:.75rem">(simulasi, bukan hack sungguhan)</p></div></body></html>`;
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    setResult(`<iframe srcdoc="${html.replace(/"/g, '&quot;')}" style="width:100%;height:220px;border:0;border-radius:8px"></iframe><br><a class="v-btn" style="margin-top:10px" href="${url}" download="locked.html"><i class="fas fa-download"></i> Download HTML</a>`);
}
function specialDeploy() {
    setResult(`⚠️ Deploy otomatis ke Vercel butuh token API yang belum dikonfigurasi di tools ini.<br><br>Cara manual: salin HTML kamu, buka <a href="https://vercel.com/new" target="_blank" style="color:var(--primary-light)">vercel.com/new</a>, lalu drag & drop file HTML-nya ke sana.`);
}
function specialSusun() {
    setResult('<i class="fas fa-circle-notch spin"></i> Mengambil soal...');
    fetch(SX + '/games/susun-kata?apikey=FREE').then(r => r.json()).then(d => {
        const soal = (d && d.data && d.data.soal) || (d && d.soal) || (d && d.result && d.result.soal);
        if (!soal) return setResult('❌ Gagal mengambil soal.');
        setResult(`
            <p style="margin-bottom:10px">Susun huruf berikut: <b style="letter-spacing:3px;font-size:1.1rem">${escapeHtml(soal)}</b></p>
            <input class="v-input" id="susunAns" placeholder="Jawaban kamu">
            <button class="v-btn" onclick="toast('Fitur cek jawaban menyesuaikan API penyedia soal.')"><i class="fas fa-check"></i> Cek Jawaban</button>
        `);
    }).catch(() => setResult('❌ Gagal mengambil soal dari server.'));
}

// ================= SARAN =================
function doSendSaran() {
    const text = document.getElementById('saranInput').value.trim();
    const st = document.getElementById('saranStatus');
    if (!text) { st.style.color = '#dc2626'; st.textContent = '⚠️ Tulis saran dulu!'; return; }
    st.style.color = '#22c55e'; st.textContent = '✅ Saran terkirim, makasih masukannya!';
    document.getElementById('saranInput').value = '';
}
