/* ============================================================
   NOXORA — ANTI INSPECT / ANTI DEVTOOLS (lapisan deterrent)
   Ini pemalas niat (deterrent), BUKAN tembok baja. Siapapun yang
   paham bisa matiin JS lewat flag browser atau baca file ini
   lewat "View Source" / curl / network request langsung —
   itu cara kerja browser, gak ada JS yang bisa menutup itu
   100%. Yang script ini lakuin: bikin orang iseng/kasual mikir
   dua kali, dan nutup jalan paling gampang (klik kanan,
   shortcut devtools, drag gambar).

   Kunci API (NEXORA_API_KEY) dan password DEV sudah dipindah ke server (api/*.js, env Vercel).
   Jangan pernah taruh key lagi di script.js / index.html. Pemanggilan API berkey
   harus lewat serverless function biar key-nya gak dikirim ke browser.
   ============================================================ */
(function () {
    'use strict';

    const isTouch = matchMedia('(pointer:coarse)').matches;

    function showGuard(msg) {
        let g = document.getElementById('nxGuard');
        if (!g) {
            g = document.createElement('div');
            g.id = 'nxGuard';
            g.style.cssText =
                'position:fixed;inset:0;z-index:999999;display:flex;flex-direction:column;' +
                'align-items:center;justify-content:center;gap:10px;text-align:center;' +
                'background:rgba(5,5,10,.97);color:#fff;font-family:Poppins,sans-serif;' +
                'padding:24px;backdrop-filter:blur(6px)';
            g.innerHTML =
                '<div style="font-size:2.2rem">🔒</div>' +
                '<div style="font-weight:700;font-size:1.05rem" id="nxGuardMsg"></div>' +
                '<div style="opacity:.6;font-size:.78rem;max-width:320px">Tutup Developer Tools lalu halaman akan jalan normal lagi.</div>';
            document.body.appendChild(g);
        }
        document.getElementById('nxGuardMsg').textContent = msg;
        g.style.display = 'flex';
    }
    function hideGuard() {
        const g = document.getElementById('nxGuard');
        if (g) g.style.display = 'none';
    }

    // ---- blokir klik kanan & drag gambar ----
    document.addEventListener('contextmenu', e => e.preventDefault());
    document.addEventListener('dragstart', e => {
        if (e.target && e.target.tagName === 'IMG') e.preventDefault();
    });

    // ---- blokir shortcut umum buat buka devtools / view-source / save ----
    document.addEventListener('keydown', function (e) {
        const k = e.key;
        const ctrlOrMeta = e.ctrlKey || e.metaKey;
        const blocked =
            k === 'F12' ||
            (ctrlOrMeta && e.shiftKey && ['I', 'i', 'J', 'j', 'C', 'c'].includes(k)) ||
            (ctrlOrMeta && ['U', 'u', 'S', 's'].includes(k));
        if (blocked) {
            e.preventDefault();
            e.stopPropagation();
            return false;
        }
    }, true);

    // ---- console warning (anti self-XSS / paste-script orang iseng) ----
    try {
        console.log('%cSTOP!', 'color:#dc2626;font-size:46px;font-weight:900;-webkit-text-stroke:1px #000');
        console.log('%cIni fitur browser buat developer. Kalau ada yang nyuruh paste sesuatu di sini, itu kemungkinan besar penipuan (akun bisa diambil alih).', 'font-size:14px');
    } catch (_) {}

    if (isTouch) return; // dimensi window gak relevan di HP, cukup sampai sini

    // ---- deteksi devtools lewat selisih ukuran window (docked devtools) ----
    const THRESHOLD = 160;
    let guardOn = false;
    setInterval(function () {
        const wDiff = window.outerWidth - window.innerWidth;
        const hDiff = window.outerHeight - window.innerHeight;
        const open = wDiff > THRESHOLD || hDiff > THRESHOLD;
        if (open && !guardOn) {
            guardOn = true;
            showGuard('Developer Tools terdeteksi aktif.');
        } else if (!open && guardOn) {
            guardOn = false;
            hideGuard();
        }
    }, 800);
})();
