// Vercel Edge Middleware — jalan di server Vercel SEBELUM file statis
// (index.html/style.css/script.js) dikirim ke browser. Ini lapisan
// anti-scrape di sisi server: request dari tool scraping/bot otomatis
// ditolak sebelum sempat baca isi file sama sekali.
//
// CATATAN JUJUR: ini nyaring User-Agent, yang gampang dipalsukan sama
// scraper yang niat banget (tinggal set UA jadi "Chrome biasa"). Tapi
// ini nutup 90% bot/scraper generik yang gak repot-repot ganti UA
// (curl, wget, python-requests, scrapy, dst), dan gratis buat dipasang.
import { next } from '@vercel/edge';

const BLOCKED_UA = [
  'curl', 'wget', 'python-requests', 'python-urllib', 'urllib',
  'scrapy', 'go-http-client', 'okhttp', 'java/', 'libwww-perl',
  'httpclient', 'axios/', 'node-fetch', 'aiohttp', 'phantomjs',
  'headlesschrome', 'puppeteer', 'playwright', 'selenium',
  'scraper', 'crawler', 'spider', 'bot/', 'httpie', 'postmanruntime',
];

export default function middleware(request) {
  const ua = (request.headers.get('user-agent') || '').toLowerCase();

  // UA kosong hampir gak pernah dipakai browser asli
  if (!ua) {
    return new Response('Forbidden', { status: 403 });
  }
  if (BLOCKED_UA.some((p) => ua.includes(p))) {
    return new Response('Forbidden', { status: 403 });
  }

  return next();
}

export const config = {
  // semua path kecuali file gambar/font yang sering di-hotlink doang
  // (biar gak tambah beban buat request aset yang sudah aman)
  matcher: ['/((?!_vercel|.*\\.(?:mp4|webm|mp3|m4a)$).*)'],
};
