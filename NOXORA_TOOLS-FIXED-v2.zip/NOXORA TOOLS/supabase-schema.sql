-- Jalankan sekali di Supabase SQL Editor sebelum deploy.
create extension if not exists pgcrypto;
create table if not exists public.app_users (
  id uuid primary key default gen_random_uuid(),
  username text not null unique,
  password_hash text not null,
  salt text not null,
  role text not null default 'MEMBER' check (role in ('MEMBER','VIP','ADMIN')),
  created_at timestamptz not null default now()
);
create table if not exists public.app_tools (
  id text primary key,
  name text not null,
  category text not null default 'tools',
  config jsonb not null default '{}'::jsonb,
  maintenance boolean not null default false,
  maintenance_message text not null default 'Tools sedang maintenance',
  created_at timestamptz not null default now()
);
create table if not exists public.app_music (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  url text not null,
  created_at timestamptz not null default now()
);
create table if not exists public.app_settings (
  key text primary key,
  value jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
-- Semua akses browser ditolak. Serverless API memakai SUPABASE_SECRET_KEY dari environment.
alter table public.app_users enable row level security;
alter table public.app_tools enable row level security;
alter table public.app_music enable row level security;
alter table public.app_settings enable row level security;
revoke all on public.app_users, public.app_tools, public.app_music, public.app_settings from anon, authenticated;
