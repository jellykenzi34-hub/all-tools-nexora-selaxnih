// Cek token sesi DEV waktu halaman dibuka lagi (supaya role DEV tidak bisa dipalsukan lewat localStorage biasa).
const { verify } = require('./_auth');

module.exports = (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    if (req.method !== 'POST') return res.status(405).json({ ok: false });
    const d = verify((req.body || {}).token);
    if (!d || !process.env.DEV_USER || d.u !== process.env.DEV_USER) return res.status(200).json({ ok: false });
    return res.status(200).json({ ok: true, user: d.u });
};
