// Helper token sesi DEV (HMAC). File berawalan "_" tidak dijadikan endpoint oleh Vercel.
const crypto = require('crypto');

const secret = () => process.env.SESSION_SECRET || process.env.DEV_PASS || '';
const b64 = (s) => Buffer.from(s).toString('base64url');

function sign(user, days = 30) {
    const payload = b64(JSON.stringify({ u: user, exp: Date.now() + days * 86400000 }));
    const sig = crypto.createHmac('sha256', secret()).update(payload).digest('base64url');
    return payload + '.' + sig;
}

function verify(token) {
    if (typeof token !== 'string' || !secret()) return null;
    const [payload, sig] = token.split('.');
    if (!payload || !sig) return null;
    const expect = crypto.createHmac('sha256', secret()).update(payload).digest('base64url');
    const a = Buffer.from(sig), b = Buffer.from(expect);
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
    try {
        const d = JSON.parse(Buffer.from(payload, 'base64url').toString());
        if (!d.exp || d.exp < Date.now()) return null;
        return d;
    } catch { return null; }
}

function safeEq(a, b) {
    const ha = crypto.createHash('sha256').update(String(a)).digest();
    const hb = crypto.createHash('sha256').update(String(b)).digest();
    return crypto.timingSafeEqual(ha, hb);
}

module.exports = { sign, verify, safeEq };
