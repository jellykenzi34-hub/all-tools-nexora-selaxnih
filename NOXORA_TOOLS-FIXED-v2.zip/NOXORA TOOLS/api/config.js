// Site key Turnstile itu publik (memang dipakai di browser), tapi diambil dari env biar semua setting di satu tempat.
module.exports = (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    res.status(200).json({ turnstileSiteKey: process.env.TURNSTILE_SITE_KEY || '' });
};
