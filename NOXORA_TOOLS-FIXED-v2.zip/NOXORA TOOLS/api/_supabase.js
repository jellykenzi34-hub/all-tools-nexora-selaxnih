const BASE = (process.env.SUPABASE_URL || '').replace(/\/$/, '');
const KEY = process.env.SUPABASE_SECRET_KEY || '';
async function db(table, {method='GET', query='', body, prefer}={}) {
  if (!BASE || !KEY) throw new Error('Supabase belum dikonfigurasi di Vercel.');
  const r = await fetch(`${BASE}/rest/v1/${table}${query ? '?' + query : ''}`, {
    method, headers: { apikey: KEY, Authorization: `Bearer ${KEY}`, 'Content-Type':'application/json', ...(prefer ? {Prefer:prefer}: {}) },
    ...(body !== undefined ? {body:JSON.stringify(body)} : {})
  });
  const txt = await r.text(); let data=null; try { data=txt?JSON.parse(txt):null; } catch {}
  if (!r.ok) throw new Error((data && (data.message || data.hint)) || `Supabase HTTP ${r.status}`);
  return data;
}
module.exports={db};
