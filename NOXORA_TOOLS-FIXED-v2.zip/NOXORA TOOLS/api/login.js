// Login akun DEV. Username & password diambil dari env Vercel (DEV_USER, DEV_PASS),
// jadi TIDAK pernah ada di file yang dikirim ke browser.
const { sign, safeEq } = require('./_auth');

module.exports = async (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    if (req.method !== 'POST') return res.status(405).json({ ok: false });

    const DEV_USER = process.env.DEV_USER, DEV_PASS = process.env.DEV_PASS;
    if (!DEV_USER || !DEV_PASS) {
        return res.status(500).json({ ok: false, message: 'DEV_USER / DEV_PASS belum diatur di Vercel.' });
    }

    const { username, password } = req.body || {};
    const okU = safeEq(username || '', DEV_USER);
    const okP = safeEq(password || '', DEV_PASS);
    if (!(okU && okP)) {
        await new Promise((r) => setTimeout(r, 400)); // perlambat tebak-tebakan password
        return res.status(401).json({ ok: false });
    }
    return res.status(200).json({ ok: true, user: DEV_USER, token: sign(DEV_USER) });
};
