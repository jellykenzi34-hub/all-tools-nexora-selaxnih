// Proxy semua tools yang butuh API key NEXORA. Key diambil dari env Vercel (NEXORA_API_KEY)
// dan ditambahkan DI SERVER, jadi tidak pernah dikirim ke browser / ada di script.js.
// Hanya endpoint di whitelist (TOOLS) yang bisa dipanggil, + wajib lolos captcha Turnstile.
const BASE = 'https://api.nexadev.my.id';

// pid -> path tujuan + parameter yang boleh diteruskan (nama param tujuan)
const TOOLS = {
    ambulk:      { path: '/am/bulk',            params: ['amount', 'orderId'] },
    amsend:      { path: '/am/send/',           params: ['email'] },
    amverif:     { path: '/am/verif/',          params: ['email', 'link'] },
    bypass:      { path: '/api/bypass',         params: ['url'] },
    tiktokview:  { path: '/api/tiktokview/',    params: ['url', 'qty'] },
    channelmem:  { path: '/api/channelmem/',    params: ['url', 'quantity'] },
};

module.exports = async (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    if (req.method !== 'POST') return res.status(405).json({ message: 'Method tidak diizinkan.' });

    const secret = process.env.TURNSTILE_SECRET_KEY, apiKey = (process.env.NEXORA_API_KEY || '').trim().replace(/^["']|["']$/g, '');
    if (!secret || !apiKey) {
        return res.status(500).json({ message: 'Server belum dikonfigurasi (TURNSTILE_SECRET_KEY / NEXORA_API_KEY).' });
    }

    const { pid, params, token } = req.body || {};
    const tool = Object.prototype.hasOwnProperty.call(TOOLS, pid) ? TOOLS[pid] : null;
    if (!tool) return res.status(400).json({ message: 'Tools tidak dikenal.' });
    if (typeof token !== 'string' || !token) return res.status(400).json({ message: 'Captcha belum diselesaikan.' });

    // validasi & saring parameter (hanya yang di whitelist, hanya string/angka, panjang dibatasi)
    const qs = new URLSearchParams();
    for (const k of tool.params) {
        const v = params && params[k];
        if (v === undefined || v === null || v === '') continue;
        if (typeof v !== 'string' && typeof v !== 'number') return res.status(400).json({ message: 'Parameter tidak valid.' });
        const s = String(v);
        if (s.length > 500) return res.status(400).json({ message: 'Parameter terlalu panjang.' });
        qs.append(k, s);
    }

    // 1) verifikasi captcha ke Cloudflare
    const form = new URLSearchParams({ secret, response: token });
    const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (ip) form.append('remoteip', ip);
    let check;
    try {
        const v = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', { method: 'POST', body: form });
        check = await v.json();
    } catch {
        return res.status(502).json({ message: 'Gagal verifikasi captcha, coba lagi.' });
    }
    if (!check.success) {
        return res.status(403).json({ message: 'Captcha tidak valid atau kedaluwarsa. Selesaikan captcha lagi.' });
    }

    // 2) teruskan ke API tujuan, key ditambahkan di sini (server-side)
    qs.append('key', apiKey);
    try {
        const up = await fetch(BASE + tool.path + '?' + qs.toString(), { signal: AbortSignal.timeout(25000) });
        const txt = await up.text();
        if (!up.ok) return res.status(502).json({ message: 'Server tujuan gagal merespons (HTTP ' + up.status + ').' });
        res.setHeader('Content-Type', up.headers.get('content-type') || 'text/plain; charset=utf-8');
        return res.status(200).send(txt);
    } catch {
        return res.status(502).json({ message: 'Server tujuan tidak merespons. Coba lagi nanti.' });
    }
};
