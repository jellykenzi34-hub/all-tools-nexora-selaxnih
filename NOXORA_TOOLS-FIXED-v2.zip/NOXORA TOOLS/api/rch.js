// React Saluran: wajib lolos captcha Cloudflare Turnstile (diverifikasi di server),
// baru request diteruskan ke API tujuan dengan API key dari env (NEXORA_API_KEY).
const UPSTREAM = 'https://api.nexadev.my.id/api/rch';

module.exports = async (req, res) => {
    res.setHeader('Cache-Control', 'no-store');
    if (req.method !== 'POST') return res.status(405).json({ message: 'Method tidak diizinkan.' });

    const secret = process.env.TURNSTILE_SECRET_KEY, apiKey = (process.env.NEXORA_API_KEY || '').trim().replace(/^["']|["']$/g, '');
    if (!secret || !apiKey) {
        return res.status(500).json({ message: 'Server belum dikonfigurasi (TURNSTILE_SECRET_KEY / NEXORA_API_KEY).' });
    }

    const { url, reaction, token } = req.body || {};
    if (typeof token !== 'string' || !token) return res.status(400).json({ message: 'Captcha belum diselesaikan.' });
    if (typeof url !== 'string' || url.length > 300 || !/^https?:\/\//i.test(url)) {
        return res.status(400).json({ message: 'Link postingan tidak valid.' });
    }
    const emoji = typeof reaction === 'string' ? reaction.trim().slice(0, 16) : '';
    if (!emoji) return res.status(400).json({ message: 'Reaction wajib diisi.' });

    // 1) verifikasi captcha ke Cloudflare
    const form = new URLSearchParams({ secret, response: token });
    const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim();
    if (ip) form.append('remoteip', ip);
    let check;
    try {
        const v = await fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', { method: 'POST', body: form });
        check = await v.json();
    } catch {
        return res.status(502).json({ message: 'Gagal verifikasi captcha, coba lagi.' });
    }
    if (!check.success || (check.action && check.action !== 'rch')) {
        return res.status(403).json({ message: 'Captcha tidak valid atau kedaluwarsa. Selesaikan captcha lagi.' });
    }

    // 2) teruskan ke API tujuan
    const qs = new URLSearchParams({ url, reaction: emoji, apikey: apiKey, key: apiKey }); // kirim dua nama param, tools NEXORA lain pakai "key"
    try {
        const up = await fetch(UPSTREAM + '?' + qs.toString(), { signal: AbortSignal.timeout(20000) });
        const txt = await up.text();
        if (!up.ok) return res.status(502).json({ message: 'Server tujuan gagal merespons (HTTP ' + up.status + ').' });
        res.setHeader('Content-Type', up.headers.get('content-type') || 'text/plain; charset=utf-8');
        return res.status(200).send(txt);
    } catch {
        return res.status(502).json({ message: 'Server tujuan tidak merespons. Coba lagi nanti.' });
    }
};
