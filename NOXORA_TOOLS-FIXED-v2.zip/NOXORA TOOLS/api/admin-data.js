const { verify } = require('./_auth');
const { db } = require('./_supabase');
module.exports = async (req,res) => {
  res.setHeader('Cache-Control','no-store');
  try {
    const action = (req.query && req.query.action) || (req.body && req.body.action) || 'public';
    const body=req.body||{};
    const d=verify(req.headers.authorization?.replace(/^Bearer\s+/i,'') || body.token);
    let isDev=!!(d && process.env.DEV_USER && d.u===process.env.DEV_USER); if(d && !isDev){try{const rows=await db('app_users',{query:'select=role&username=eq.'+encodeURIComponent(d.u)+'&limit=1'});isDev=rows[0]?.role==='ADMIN';}catch{}}
    if (['admin','deleteTool','setMaintenance','saveTool','deleteMusic','saveMusic','saveSetting','stats'].includes(action) && !isDev) return res.status(403).json({ok:false,message:'Akses DEV diperlukan.'});
    if (req.method==='GET' && action==='public') {
      const [tools,music,settings]=await Promise.all([
        db('app_tools',{query:'select=*&order=created_at.asc'}),
        db('app_music',{query:'select=*&order=created_at.asc'}),
        db('app_settings',{query:'select=key,value'})
      ]);
      return res.status(200).json({ok:true,tools,music,settings});
    }
    if (req.method==='GET' && action==='stats') {
      const users=await db('app_users',{query:'select=id'});
      const tools=await db('app_tools',{query:'select=id'});
      return res.status(200).json({ok:true,accounts:users.length,tools:tools.length});
    }
    if (req.method==='POST' && action==='saveTool') {
      const row={id:String(body.tool.id||body.tool.key||('tool_'+Date.now())), name:String(body.tool.name||'').slice(0,100), category:String(body.tool.category||'tools'), config:body.tool};
      const out=await db('app_tools',{method:'POST',query:'on_conflict=id',body:row,prefer:'resolution=merge-duplicates,return=representation'});
      return res.status(200).json({ok:true,data:out});
    }
    if (req.method==='POST' && action==='deleteTool') { await db('app_tools',{method:'DELETE',query:'id=eq.'+encodeURIComponent(String(body.id))}); return res.status(200).json({ok:true}); }
    if (req.method==='POST' && action==='setMaintenance') {
      const row={id:String(body.id), maintenance:!!body.enabled, maintenance_message:String(body.message||'Tools sedang maintenance').slice(0,250)};
      await db('app_tools',{method:'PATCH',query:'id=eq.'+encodeURIComponent(row.id),body:{maintenance:row.maintenance,maintenance_message:row.maintenance_message},prefer:'return=minimal'});
      return res.status(200).json({ok:true});
    }
    if (req.method==='POST' && action==='saveMusic') { const row={name:String(body.name||'').slice(0,100),url:String(body.url||'').slice(0,1000)}; if(!row.name||!/^https?:\/\//i.test(row.url)) return res.status(400).json({ok:false,message:'Nama dan URL HTTP(S) wajib.'}); const out=await db('app_music',{method:'POST',body:row,prefer:'return=representation'}); return res.status(200).json({ok:true,data:out}); }
    if (req.method==='POST' && action==='deleteMusic') { await db('app_music',{method:'DELETE',query:'id=eq.'+encodeURIComponent(String(body.id))}); return res.status(200).json({ok:true}); }
    if (req.method==='POST' && action==='saveSetting') { await db('app_settings',{method:'POST',query:'on_conflict=key',body:{key:String(body.key),value:body.value},prefer:'resolution=merge-duplicates,return=minimal'}); return res.status(200).json({ok:true}); }
    return res.status(405).json({ok:false,message:'Method/action tidak didukung.'});
  } catch(e) { return res.status(500).json({ok:false,message:e.message||'Kesalahan server'}); }
};
