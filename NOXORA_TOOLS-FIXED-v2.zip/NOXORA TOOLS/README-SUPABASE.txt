NOXORA TOOLS — setup database

1. Supabase > SQL Editor: jalankan supabase-schema.sql.
2. Vercel > Project > Settings > Environment Variables, tambahkan:
   SUPABASE_URL = URL project Supabase
   SUPABASE_SECRET_KEY = secret/service-role key project (server only; never put in frontend)
   DEV_USER, DEV_PASS, SESSION_SECRET, TURNSTILE_SITE_KEY, TURNSTILE_SECRET_KEY sesuai konfigurasi aplikasi.
3. Redeploy Vercel setelah mengubah environment variables.
4. Buat akun admin: daftar akun biasa, lalu di Supabase SQL Editor jalankan:
   update public.app_users set role='ADMIN' where username='USERNAME_ANDA';
   Keluar lalu masuk lagi agar role admin terbaca. Jangan berikan role ADMIN ke pengguna yang tidak dipercaya.
5. Akun baru disimpan ke Supabase. Password disimpan sebagai hash scrypt + salt, bukan teks biasa.

Fitur yang ditambahkan:
- Tools kategori VIP tidak lagi ditolak hanya karena role MEMBER.
- Menu DEV untuk statistik akun dan tools database, serta menghapus tools custom.
- Menu Kontrol Tools untuk maintenance sementara dengan pesan custom.
- Form tambah tools menerima field input JSON, metode GET/POST, dan daftar tombol API JSON opsional.
- Musik bawaan NEXORA dihapus; playlist dimulai dari lagu yang ditambahkan.

Format Input API contoh:
[{"k":"url","l":"URL target","ph":"https://..."},{"k":"quality","l":"Kualitas","opts":["720p","1080p"]}]

Format Tombol API contoh:
[{"label":"Download","icon":"fa-download","base":"https://api.example.com/download","use":["url"]},{"label":"Info","icon":"fa-circle-info","base":"https://api.example.com/info","use":["url"]}]

Catatan:
- Tombol API memerlukan endpoint yang memang mendukung metode dan parameter yang dikonfigurasi. Browser tidak dapat menembus CORS pada API pihak ketiga.
- Semua akses database menggunakan API serverless dengan SUPABASE_SECRET_KEY; jangan pernah mengirim key itu ke browser atau menyimpan nilai rahasia di repository.
- Tools lama yang disimpan hanya di localStorage tetap bersifat lokal di browser itu sampai dibuat ulang/ditambahkan ke database.
